FIVE SOLARIS WEBSITE
====================

Files
-----
- index.html: complete responsive website (HTML, CSS, JavaScript in one file)

Preview locally
---------------
1. Extract the ZIP.
2. Double-click index.html to open it in your browser.
3. Internet access is needed to load the sample photography.

Before publishing
-----------------
1. Open index.html in a text editor (Notepad or VS Code).
2. Search for: const WHATSAPP_NUMBER = "63XXXXXXXXXX";
3. Replace it with your actual Philippine WhatsApp number in international format, digits only.
   Example format: 639171234567 (do not include +, spaces, or dashes).
4. Update the service area, Facebook link, and any business contact details.
5. Replace sample portfolio images/captions with your real completed-project photos.
6. Review all services and claims so they match the work your team is prepared and authorized to perform.

Publishing
----------
You can upload index.html to a static hosting provider or web host. A custom domain is optional but recommended for a professional business presence.

Notes
-----
- The quotation form opens WhatsApp with a pre-filled message. It does not save leads to a database.
- No contact number, email, license details, or company registration details were invented.
- The current site uses remote sample images from Unsplash, so those images require internet access.
