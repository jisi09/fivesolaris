FIVE SOLARIS WEBSITE
====================

Files
-----
- index.html: responsive website (HTML, CSS, JavaScript in one file)

Business details configured
---------------------------
- WhatsApp: +63 927 609 1134
- Email: jisifriolo@gmail.com
- Facebook: https://www.facebook.com/share/1FM193ZyDC/?mibextid=wwXIfr
- Service area: Cebu Province, Philippines

Website features
----------------
- Electrical and solar services
- Sample project gallery (clearly marked as sample images)
- Solar budget estimator for grid-tied, hybrid, and off-grid systems
- Illustrative down-payment and monthly balance calculations
- Quote form with cash/bank transfer, installment inquiry, and down-payment preference
- WhatsApp inquiry generation, email, and Facebook links

Important pricing/payment notes
-------------------------------
- Solar price ranges are rough planning estimates only, not a formal quote.
- Final cost depends on equipment, battery capacity, roof/site conditions, permits, wiring, logistics, and project scope.
- Monthly installment estimates divide the remaining indicative balance by the selected number of months. They do not include interest, fees, or credit approval.
- Installment payment is NOT guaranteed. It is subject to assessment and a written agreement with the business.
- No financing company, loan, or credit facility is advertised as available.
- The quotation form opens WhatsApp with a pre-filled message. It does not save leads to a database.

Preview locally
---------------
1. Extract the ZIP.
2. Double-click index.html to open it in your browser.
3. Internet access is needed to load the sample photography.

Publishing
----------
Upload the new ZIP's contents or the index.html file to your existing Netlify site using the site's deploy workflow. The live website will not change until the updated files are published.

Before promoting the website
----------------------------
- Confirm the WhatsApp number, email, and Facebook link work.
- Replace sample project images with actual completed-work photos when available.
- Review price estimates and payment terms against your supplier costs, margins, labor, transport, taxes, permits, and actual business capacity before offering a customer a formal quote.
